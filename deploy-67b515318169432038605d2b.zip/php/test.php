<?php
include 'config.php';
echo "Conexión exitosa a MySQL";
?>
