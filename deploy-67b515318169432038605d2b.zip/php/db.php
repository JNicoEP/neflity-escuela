<?php
$host = "localhost";
$user = "root"; // Cambia esto si es necesario
$pass = ""; // Pon tu contraseña de MySQL si tienes
$db = "aula_virtual";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
