<?php
session_start();
include 'config.php'; // Conexión a la base de datos

$servername = "localhost";
$username = "root"; // Cambia esto si es necesario
$password = ""; // Cambia esto si es necesario
$dbname = "aula_virtual";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT id, username, password, rol FROM usuarios WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $username, $hashed_password, $rol);

if ($stmt->fetch() && password_verify($password, $hashed_password)) {
    $_SESSION['username'] = $username;
    $_SESSION['rol'] = $rol;

    if ($rol == 'profesor') {
        header("Location: ../profesor.html");
    } else {
        header("Location: ../alumno.html");
    }
} else {
    echo "Usuario o contraseña incorrectos.";
}

$stmt->close();
$conn->close();
?>