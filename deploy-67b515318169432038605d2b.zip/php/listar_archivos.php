<?php
$uploadDirectory = "C:/Users/JNICOEP/Desktop/facultad/proyecto/aula-virtual/docs/archivos/";

$archivos = [];

if (is_dir($uploadDirectory)) {
    $files = scandir($uploadDirectory);
    foreach ($files as $file) {
        if ($file !== "." && $file !== "..") {
            $archivos[] = [
                "nombre" => $file,
                "fecha" => date("Y-m-d H:i:s", filemtime($uploadDirectory . $file)),
                "ruta" => $uploadDirectory . $file
            ];
        }
    }
}

echo json_encode($archivos);
?>