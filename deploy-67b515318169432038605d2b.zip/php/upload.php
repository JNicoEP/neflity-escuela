<?php
$uploadDirectory = "C:/Users/JNICOEP/Desktop/facultad/proyecto/aula-virtual/docs/archivos/"; // Carpeta donde se guardarán los archivos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['fileInput']) && $_FILES['fileInput']['error'] === UPLOAD_ERR_OK) {
        $fileName = basename($_FILES['fileInput']['name']);
        $uploadFilePath = $uploadDirectory . $fileName;

        if (move_uploaded_file($_FILES['fileInput']['tmp_name'], $uploadFilePath)) {
            echo json_encode([
                "status" => "success",
                "filePath" => $uploadFilePath,
                "fileName" => $fileName
            ]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al subir el archivo."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No se ha seleccionado ningún archivo."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método de solicitud no válido."]);
}
?>