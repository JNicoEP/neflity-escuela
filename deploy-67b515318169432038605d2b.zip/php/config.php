<?php
$servername = "localhost"; 
$username = "root";  // Usuario por defecto en XAMPP
$password = "";      // En XAMPP, la contraseña por defecto es vacía
$dbname = "aula_virtual"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
